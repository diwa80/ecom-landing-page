# responsive carousel Bootstrap 5
Bootstrap 5 customizable multi item carousel

Make sure to include the bootsrap, jquery, javascript and popper js links.


Use the same code over and over and the code will work fine.
Make sure to do the below ↓ everytime
Edit all the 'trendingCarousel' to any name. EVerything works, even if you have existing carousel.
